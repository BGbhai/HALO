#!/usr/bin/env python3
"""
HALO Integrated Toy Demonstration v2

This reproduces the original 5-qubit toy demo with one key operational upgrade:
backend fallback. If Aer is unavailable or unhealthy, the script automatically
uses BasicSimulator and records the selected backend.
"""

from __future__ import annotations

import math
import os

from qiskit import QuantumCircuit

from experiments.backends import CircuitRunner

SHOTS = 4096
REQUESTED_BACKEND = os.environ.get("HALO_BACKEND", "simulator")
RUNNER = CircuitRunner(requested_backend=REQUESTED_BACKEND, seed=7)


def build_dfs_init() -> QuantumCircuit:
    qc = QuantumCircuit(2, name="DFS_Init")
    qc.h(0)
    qc.x(1)
    qc.cx(0, 1)
    return qc


def build_epoch_gate() -> QuantumCircuit:
    epoch = QuantumCircuit(4, name="Epoch")

    epoch.x(1)
    epoch.mcx([0, 1], 3)
    epoch.x(1)

    epoch.z(3)

    epoch.x(1)
    epoch.mcx([0, 1], 3)
    epoch.x(1)

    epoch.cx(0, 2)

    epoch.cx(0, 1)
    epoch.x(1)
    epoch.h(0)

    return epoch


def build_full_circuit(noise_angle: float = math.pi / 3, measure_all: bool = False) -> QuantumCircuit:
    n_classical = 5 if measure_all else 3
    qc = QuantumCircuit(5, n_classical)

    qc.h(0)

    dfs = build_dfs_init()
    qc.append(dfs.to_gate(), [1, 2])

    qc.cx(1, 3)

    if noise_angle != 0:
        qc.rz(noise_angle, 1)
        qc.rz(noise_angle, 2)

    qc.barrier()

    epoch = build_epoch_gate()
    controlled_epoch = epoch.to_gate().control(1)
    qc.append(controlled_epoch, [0, 1, 2, 3, 4])

    qc.barrier()

    if measure_all:
        qc.measure([0, 1, 2, 3, 4], [0, 1, 2, 3, 4])
    else:
        qc.measure(0, 0)
        qc.measure([1, 2], [1, 2])

    return qc


def run_circuit(circuit: QuantumCircuit, shots: int = SHOTS):
    return RUNNER.run_counts(circuit, shots=shots).counts


def parse_counts(counts):
    parsed = {}
    for bitstring, count in counts.items():
        natural = bitstring.replace(" ", "")[::-1]
        parsed[natural] = parsed.get(natural, 0) + count
    return parsed


def test_ancilla_factorization() -> bool:
    print("=" * 65)
    print("TEST 1: Ancilla Factorization (Full 5-Qubit Diagnostic)")
    print("=" * 65)

    circuit = build_full_circuit(noise_angle=math.pi / 3, measure_all=True)
    counts = run_circuit(circuit)
    parsed = parse_counts(counts)

    t0_outcomes = {k: v for k, v in parsed.items() if k[0] == "0"}
    t1_outcomes = {k: v for k, v in parsed.items() if k[0] == "1"}

    t0_total = sum(t0_outcomes.values())
    t1_total = sum(t1_outcomes.values())

    print(f"\n  --- Clock t=0 outcomes ({t0_total} shots) ---")
    print("  q3 is entangled with q1 by design (boundary map active)")
    print(f"  {'State (q0 q1 q2 q3 q4)':<30} {'Count':>8} {'Note'}")
    print("  " + "-" * 55)

    for state in sorted(t0_outcomes.keys()):
        count = t0_outcomes[state]
        note = "(q3 tracks q1 -- expected)" if state[3] == state[1] else ""
        print(f"  |{state}>{'':<20} {count:>8}  {note}")

    print(f"\n  --- Clock t=1 outcomes ({t1_total} shots) ---")
    print("  Epoch has fired: q3 and q4 must BOTH be |0>")
    print(f"  {'State (q0 q1 q2 q3 q4)':<30} {'Count':>8} {'Status'}")
    print("  " + "-" * 55)

    t1_ancilla_clean = True
    for state in sorted(t1_outcomes.keys()):
        count = t1_outcomes[state]
        q3, q4 = state[3], state[4]
        status = "OK" if (q3 == "0" and q4 == "0") else "LEAKAGE"
        if status != "OK":
            t1_ancilla_clean = False
        print(f"  |{state}>{'':<20} {count:>8}  {status}")

    expected_t1 = t1_outcomes.get("11000", 0)
    print()
    if t1_ancilla_clean:
        print("  PASS: At t=1, all ancillas (q3, q4) = |0>.")
        if expected_t1 == t1_total:
            print("        Target state |11000> = 100% of t=1 outcomes.")
        else:
            pct = 100 * expected_t1 / max(1, t1_total)
            print(f"        Target state |11000>: {pct:.1f}% of t=1 outcomes.")
    else:
        print("  FAIL: Ancilla leakage detected at t=1.")

    return t1_ancilla_clean


def test_dfs_resilience() -> bool:
    print("\n" + "=" * 65)
    print("TEST 2: DFS Noise Resilience (Collective Dephasing Sweep)")
    print("=" * 65)

    angles = [0, math.pi / 6, math.pi / 3, math.pi / 2, math.pi, 3 * math.pi / 2]
    labels = ["0", "pi/6", "pi/3", "pi/2", "pi", "3pi/2"]

    target_fractions = []
    print(f"\n  {'theta':<10} {'t=0 |01>':<12} {'t=0 |10>':<12} {'t=1 |10>':<12} {'t=1 other':<12}")
    print("  " + "-" * 58)

    for angle, label in zip(angles, labels):
        circuit = build_full_circuit(noise_angle=angle, measure_all=False)
        parsed = parse_counts(run_circuit(circuit))

        t0_01 = parsed.get("001", 0)
        t0_10 = parsed.get("010", 0)
        t1_target = parsed.get("110", 0)
        t1_other = sum(v for k, v in parsed.items() if k[0] == "1" and k != "110")

        frac = t1_target / max(1, t1_target + t1_other)
        target_fractions.append(frac)

        print(f"  {label:<10} {t0_01:<12} {t0_10:<12} {t1_target:<12} {t1_other:<12}")

    passed = all(value > 0.99 for value in target_fractions)
    print()
    if passed:
        print("  PASS: Statistics invariant across all tested collective Rz angles.")
    else:
        print("  FAIL: At least one angle dropped below 99% target fraction.")

    return passed


def test_relational_time() -> bool:
    print("\n" + "=" * 65)
    print("TEST 3: Relational Time Extraction (Clock-Conditioned Evolution)")
    print("=" * 65)

    parsed = parse_counts(run_circuit(build_full_circuit(noise_angle=math.pi / 3, measure_all=False)))

    t0_counts = {k[1:]: v for k, v in parsed.items() if k[0] == "0"}
    t1_counts = {k[1:]: v for k, v in parsed.items() if k[0] == "1"}

    total = sum(parsed.values())
    t0_total = sum(t0_counts.values())
    t1_total = sum(t1_counts.values())

    print(f"\n  Total shots: {total}")
    print(f"  Clock t=0 outcomes: {t0_total} ({100 * t0_total / max(1, total):.1f}%)")
    print(f"  Clock t=1 outcomes: {t1_total} ({100 * t1_total / max(1, total):.1f}%)")

    print("\n  --- Clock t=0 (Epoch does NOT fire) ---")
    for state in sorted(t0_counts.keys()):
        frac = t0_counts[state] / max(1, t0_total)
        print(f"    Agent |{state}>: {t0_counts[state]:>6} ({100 * frac:.1f}%)")

    print("\n  --- Clock t=1 (Epoch fires) ---")
    for state in sorted(t1_counts.keys()):
        frac = t1_counts[state] / max(1, t1_total)
        marker = " <-- TARGET" if state == "10" else ""
        print(f"    Agent |{state}>: {t1_counts[state]:>6} ({100 * frac:.1f}%){marker}")

    t0_balanced = all(abs(v / max(1, t0_total) - 0.5) <= 0.1 for v in t0_counts.values())
    t1_target = t1_counts.get("10", 0)
    t1_deterministic = (t1_total > 0) and (t1_target / t1_total > 0.99)

    print()
    if t0_balanced and t1_deterministic:
        print("  PASS: t=0 superposition and t=1 deterministic target are both observed.")
    elif not t0_balanced:
        print("  FAIL: Clock t=0 distribution is not balanced.")
    else:
        pct = 100 * t1_target / max(1, t1_total)
        print(f"  FAIL: Clock t=1 target fraction = {pct:.1f}% (expected >99%).")

    return t0_balanced and t1_deterministic


def main() -> None:
    print()
    print("+" + "=" * 63 + "+")
    print("|        HALO Integrated Toy Demonstration v2 (5 Qubits)      |")
    print("|  Fallback backend mode enabled for reproducible execution.  |")
    print("+" + "=" * 63 + "+")
    print()
    print(f"  Requested backend: {RUNNER.selection.requested}")
    print(f"  Actual backend:    {RUNNER.selection.actual}")
    if RUNNER.selection.note:
        print(f"  Backend note:      {RUNNER.selection.note}")
    print(f"  Shots per experiment: {SHOTS}")
    print()

    results = []
    results.append(("Ancilla Factorization", test_ancilla_factorization()))
    results.append(("DFS Noise Resilience", test_dfs_resilience()))
    results.append(("Relational Time", test_relational_time()))

    print("\n" + "=" * 65)
    print("SUMMARY")
    print("=" * 65)

    all_passed = True
    for name, passed in results:
        status = "PASS" if passed else "FAIL"
        print(f"  [{status}]  {name}")
        if not passed:
            all_passed = False

    print()
    if all_passed:
        print("  All three tests passed on the selected backend.")
    else:
        print("  One or more tests failed. Review output above.")
    print()


if __name__ == "__main__":
    main()
