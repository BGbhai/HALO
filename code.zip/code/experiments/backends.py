#!/usr/bin/env python3
"""Backend selection and execution helpers with safe fallback behavior."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict
import os
import subprocess
import sys
import time

from qiskit import transpile
from qiskit.providers.basic_provider import BasicSimulator

try:
    from qiskit_aer import AerSimulator
except Exception:  # pragma: no cover - optional dependency
    AerSimulator = None


_AER_HEALTHCHECK = """
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
qc = QuantumCircuit(1, 1)
qc.x(0)
qc.measure(0, 0)
sim = AerSimulator()
compiled = transpile(qc, sim)
result = sim.run(compiled, shots=1).result().get_counts(compiled)
assert result
"""


@dataclass
class BackendSelection:
    requested: str
    actual: str
    note: str = ""


@dataclass
class RunResult:
    counts: Dict[str, int]
    runtime_sec: float
    selection: BackendSelection
    compiled_circuit: Any


class CircuitRunner:
    """Run circuits with stable fallback from Aer to BasicSimulator."""

    def __init__(self, requested_backend: str = "simulator", seed: int = 1) -> None:
        self.requested_backend = requested_backend
        self.seed = seed
        self._backend: Any
        self.selection: BackendSelection
        self._backend, self.selection = self._select_backend(requested_backend)

    def _select_backend(self, requested_backend: str) -> tuple[Any, BackendSelection]:
        mode = requested_backend.strip().lower()

        if mode not in {"simulator", "hardware"}:
            raise ValueError(
                f"Unsupported backend '{requested_backend}'. Expected simulator or hardware."
            )

        if mode == "hardware":
            # This environment does not guarantee IBM Runtime configuration.
            # Fall back to BasicSimulator while preserving metadata.
            backend = BasicSimulator()
            selection = BackendSelection(
                requested="hardware",
                actual="hardware_unavailable_basic_fallback",
                note=(
                    "Real hardware backend not configured in this environment. "
                    "Fell back to BasicSimulator."
                ),
            )
            return backend, selection

        if os.environ.get("HALO_FORCE_BASIC", "0") == "1":
            return BasicSimulator(), BackendSelection(
                requested="simulator",
                actual="basic_simulator",
                note="HALO_FORCE_BASIC=1",
            )

        if AerSimulator is not None and self._aer_healthcheck():
            backend = AerSimulator()
            selection = BackendSelection(
                requested="simulator",
                actual="aer_simulator",
                note="Aer healthcheck passed.",
            )
            return backend, selection

        backend = BasicSimulator()
        selection = BackendSelection(
            requested="simulator",
            actual="basic_simulator",
            note="Aer unavailable or unhealthy; using BasicSimulator.",
        )
        return backend, selection

    def _aer_healthcheck(self, timeout_sec: int = 8) -> bool:
        """Run an Aer probe in a subprocess so hard crashes do not kill parent process."""
        try:
            proc = subprocess.run(
                [sys.executable, "-c", _AER_HEALTHCHECK],
                check=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=timeout_sec,
                text=True,
            )
            return proc.returncode == 0
        except Exception:
            return False

    def run_counts(self, circuit: Any, shots: int) -> RunResult:
        compiled = transpile(circuit, self._backend, seed_transpiler=self.seed)

        run_kwargs: Dict[str, Any] = {"shots": shots}
        if self.selection.actual == "aer_simulator":
            run_kwargs["seed_simulator"] = self.seed

        start = time.perf_counter()
        try:
            job = self._backend.run(compiled, **run_kwargs)
        except TypeError:
            # BasicSimulator can reject some kwargs depending on version.
            job = self._backend.run(compiled, shots=shots)

        result = job.result()
        elapsed = time.perf_counter() - start

        counts = result.get_counts(compiled)
        return RunResult(
            counts=counts,
            runtime_sec=elapsed,
            selection=self.selection,
            compiled_circuit=compiled,
        )
