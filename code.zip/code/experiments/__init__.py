"""Experiment modules for HALO evidence pipeline v2."""
