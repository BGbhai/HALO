#!/usr/bin/env python3
"""
C4: Cross-sector holographic compression — Qiskit circuit implementation.

This script constitutes Claim C4 of the HALO evidence ladder.

Part A  Direct-sum isometry for multi-sector states.
        The k-excitation isometry from C2 is extended to a direct-sum
        V_plus: (bigoplus_{k in K} H_k) -> C^{2^m}.  The construction is
        compiled into a Qiskit circuit and circuit metrics (depth, two-qubit
        gate count) are recorded alongside the algebraic isometry error.

Part B  Sector leakage under a transverse-field perturbation.
        An initial state in the k_center sector is time-evolved under
        H = H_XY + H_Gamma, where H_Gamma = Gamma sum_i (a_i^dag + a_i)
        does not conserve excitation number.  The evolution unitary is
        compiled as a Qiskit UnitaryGate and the probability of leaving
        the k_center sector is recorded for a sweep of Gamma and t values.

Both parts use CircuitRunner for backend selection and transpilation,
and Qiskit Statevector for exact amplitude tracking.

Evidence threshold (C4)
-----------------------
  Part A: isometry error <= 1e-10 for all tested (K, N) pairs.
  Part B: leakage = 0 at Gamma = 0; strictly increasing trend in Gamma.
"""

from __future__ import annotations
import itertools, json, math, sys, time
from datetime import datetime, timezone
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
def expm(A: np.ndarray) -> np.ndarray:
    """
    Matrix exponential via eigendecomposition.  Valid for Hermitian A.
    For a general matrix A, uses numpy's built-in via eigendecomposition.
    """
    evals, evecs = np.linalg.eig(A)
    return (evecs * np.exp(evals)) @ np.linalg.inv(evecs)

try:
    from qiskit import QuantumCircuit, transpile
    from qiskit.circuit.library import UnitaryGate
    from qiskit.quantum_info import Statevector
    sys.path.insert(0, str(Path(__file__).parent))
    from experiments.backends import CircuitRunner
    _QISKIT = True
except ModuleNotFoundError:
    _QISKIT = False
    print("WARNING: qiskit not found — running in numpy-fallback mode.")
    print("         Install requirements.txt for full circuit metrics.")

# ── paths ──────────────────────────────────────────────────────────────────
ROOT   = Path(__file__).resolve().parents[1]
RESDIR = ROOT / "data"
FIGDIR = ROOT / "latex_source"
RESDIR.mkdir(parents=True, exist_ok=True)

def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


# ══════════════════════════════════════════════════════════════════════════════
# ALGEBRAIC PRIMITIVES  (shared by Parts A and B)
# ══════════════════════════════════════════════════════════════════════════════

def single_sector_basis(N: int, k: int) -> list:
    """Ordered basis of the k-excitation subspace: list of (sorted) tuples."""
    return list(itertools.combinations(range(N), k))


def multi_sector_isometry(N: int, k_sectors: list[int]):
    """
    Build V_plus: (bigoplus_{k in K} H_k) -> C^{2^m}.

    The i-th combined basis vector maps to the i-th computational basis
    state of the m-qubit boundary register.  V†V = I_D by construction.

    Returns
    -------
    V     : (2^m, D) isometry matrix (complex)
    D     : combined subspace dimension
    m     : number of boundary qubits
    basis : ordered list of (k, combo) pairs
    """
    basis = []
    for k in sorted(k_sectors):
        for b in single_sector_basis(N, k):
            basis.append((k, b))
    D = len(basis)
    m = max(1, math.ceil(math.log2(D))) if D > 1 else 1
    V = np.zeros((2 ** m, D), dtype=np.complex128)
    for i in range(D):
        V[i, i] = 1.0
    return V, D, m, basis


def extend_to_unitary(V: np.ndarray, seed: int = 42) -> np.ndarray:
    """
    Complete isometry V (2^m x D) to a full unitary (2^m x 2^m).

    The first D columns are V; the remaining (2^m - D) columns span
    the orthogonal complement and are obtained by projecting random
    vectors onto the null space of V† and orthonormalising via QR.
    """
    dim, D = V.shape
    if D == dim:
        return V.copy()
    rng = np.random.default_rng(seed)
    R = rng.standard_normal((dim, dim - D)) + 1j * rng.standard_normal((dim, dim - D))
    R -= V @ (V.conj().T @ R)
    Q, _ = np.linalg.qr(R)
    return np.hstack([V, Q])


def fock_basis(N: int, k: int) -> np.ndarray:
    """Row i is the {0,1}^N occupation vector for the i-th k-excitation state."""
    combos = list(itertools.combinations(range(N), k))
    B = np.zeros((len(combos), N), dtype=np.float64)
    for i, c in enumerate(combos):
        for j in c:
            B[i, j] = 1.0
    return B


def build_full_basis(N: int, k_min: int, k_max: int):
    """
    Ordered list of all {0,1}^N occupation vectors for k_min <= k <= k_max.
    Returns (vecs, sector_labels, index_dict).
    """
    vecs, sectors = [], []
    for k in range(k_min, k_max + 1):
        B = fock_basis(N, k)
        for row in B:
            vecs.append(tuple(row.astype(int)))
            sectors.append(k)
    idx = {v: i for i, v in enumerate(vecs)}
    return vecs, sectors, idx


def xy_hamiltonian_matrix(N: int, k: int, J: float = 1.0) -> np.ndarray:
    """XY hopping Hamiltonian in the k-excitation subspace (open chain)."""
    basis = single_sector_basis(N, k)
    D = len(basis)
    idx = {b: i for i, b in enumerate(basis)}
    H = np.zeros((D, D), dtype=np.complex128)
    for bi, b in enumerate(basis):
        occ = set(b)
        for site in range(N - 1):
            if site in occ and (site + 1) not in occ:
                new_b = tuple(sorted((occ - {site}) | {site + 1}))
                if new_b in idx:
                    H[idx[new_b], bi] += J
                    H[bi, idx[new_b]] += J
    return H


def field_perturbation_matrix(N: int, k_center: int, Gamma: float):
    """
    Transverse-field perturbation H_Gamma = Gamma sum_i (a_i^dag + a_i)
    in the combined (k_center-1, k_center, k_center+1) space.
    Returns (H_total, vecs, sectors, idx) where H_total includes H_XY.
    """
    k_min = max(0, k_center - 1)
    k_max = min(N, k_center + 1)
    vecs, sectors_list, idx = build_full_basis(N, k_min, k_max)
    D_total = len(vecs)
    H_pert = np.zeros((D_total, D_total), dtype=np.complex128)
    for bi, bv in enumerate(vecs):
        occ = list(bv)
        for site in range(N):
            if occ[site] == 0:
                new_occ = list(occ)
                new_occ[site] = 1
                nk = tuple(new_occ)
                if nk in idx:
                    H_pert[idx[nk], bi] += Gamma
                    H_pert[bi, idx[nk]] += Gamma
    # Assemble H_XY block-diagonal in the multi-sector space
    H_XY_full = np.zeros((D_total, D_total), dtype=np.complex128)
    for k in range(k_min, k_max + 1):
        H_k = xy_hamiltonian_matrix(N, k)
        basis_k = single_sector_basis(N, k)
        for bi, bv in enumerate(basis_k):
            occ_v = tuple(1 if j in set(bv) else 0 for j in range(N))
            ii = idx[occ_v]
            for bj, bw in enumerate(basis_k):
                occ_w = tuple(1 if j in set(bw) else 0 for j in range(N))
                jj = idx[occ_w]
                H_XY_full[ii, jj] += H_k[bi, bj]
    return H_XY_full + H_pert, vecs, sectors_list, idx


# ══════════════════════════════════════════════════════════════════════════════
# CIRCUIT CONSTRUCTION
# ══════════════════════════════════════════════════════════════════════════════

def _evolve_statevector_numpy(sv: np.ndarray, U: np.ndarray) -> np.ndarray:
    """Apply unitary U to state vector sv (numpy fallback)."""
    return U @ sv


def build_isometry_circuit(V: np.ndarray, m: int, label: str = "V_oplus"):
    """Return (Qiskit QuantumCircuit or None, unitary matrix U) for the isometry."""
    U = extend_to_unitary(V)
    if _QISKIT:
        gate = UnitaryGate(U, label=label)
        qc = QuantumCircuit(m, name=label)
        qc.append(gate, range(m))
        return qc, U
    return None, U


def build_evolution_circuit(H: np.ndarray, t: float, m: int, label: str = "U_t"):
    """Return (Qiskit QuantumCircuit or None, unitary matrix U) for time evolution."""
    dim_full = 2 ** m
    D = H.shape[0]
    H_full = np.zeros((dim_full, dim_full), dtype=np.complex128)
    H_full[:D, :D] = H
    U = expm(-1j * H_full * t)
    if _QISKIT:
        gate = UnitaryGate(U, label=label)
        qc = QuantumCircuit(m, name=label)
        qc.append(gate, range(m))
        return qc, U
    return None, U


def circuit_metrics(qc, runner, m: int, opt_level: int = 1) -> dict:
    """
    Compile circuit and return depth and two-qubit gate count.
    Falls back to analytical estimates when Qiskit is unavailable.
    """
    if _QISKIT and qc is not None:
        compiled = transpile(qc, runner._backend,
                             seed_transpiler=runner.seed,
                             optimization_level=opt_level)
        return {
            "circuit_depth": compiled.depth(),
            "two_qubit_gates": compiled.num_nonlocal_gates(),
            "total_gates": compiled.size(),
            "n_qubits": m,
            "backend": runner.selection.actual if runner else "numpy_fallback",
            "metrics_method": "transpiled",
        }
    # Analytical estimate: general n-qubit unitary synthesis.
    # Lower bound: (4^m - 3*2^m + 2) / 3  two-qubit gates (Shende et al. 2006).
    # Depth estimate assumes ~log-depth parallelism.
    n2q = max(1, (4**m - 3 * 2**m + 2) // 3)
    return {
        "circuit_depth": None,
        "two_qubit_gates": None,
        "total_gates": None,
        "n_qubits": m,
        "backend": "numpy_fallback",
        "metrics_method": "unavailable_qiskit_not_installed",
    }


# ══════════════════════════════════════════════════════════════════════════════
# PART A — MULTI-SECTOR DIRECT-SUM ISOMETRY
# ══════════════════════════════════════════════════════════════════════════════

def run_multi_sector(runner, seed: int = 13) -> list[dict]:
    """
    C4 Part A: verify direct-sum isometry as a compiled Qiskit circuit.

    For each (K, N) pair:
      1. Construct V_plus analytically.
      2. Compile to Qiskit circuit and record depth / two-qubit gate count.
      3. For each basis state, prepare a Statevector, evolve through the
         circuit, and verify the output matches V applied to that basis vector.
      4. Compute Frobenius isometry error and compression ratio.

    N is limited to {4, 6} so that the compiled circuit remains tractable
    (boundary register m <= 6 qubits, unitary dimension <= 64).
    """
    print("\n=== C4 Part A: cross-sector direct-sum isometry (Qiskit circuits) ===")
    rng = np.random.default_rng(seed)

    sector_combos = [[1, 2], [0, 1, 2], [1, 2, 3]]
    N_values = [4, 6]
    records = []

    for k_sectors in sector_combos:
        for N in N_values:
            V, D, m, basis = multi_sector_isometry(N, k_sectors)
            label = "k" + "_".join(str(k) for k in sorted(k_sectors))

            # Algebraic verification
            gram = V.conj().T @ V
            iso_err = float(np.linalg.norm(gram - np.eye(D), ord="fro"))
            ratio = round(N / m, 6)

            # Qiskit circuit + metrics
            qc, U_iso = build_isometry_circuit(V, m, label=label)
            metrics = circuit_metrics(qc, runner, m)

            # Statevector verification: check each basis state
            max_sv_err = 0.0
            for i in range(D):
                sv_in = np.zeros(2 ** m, dtype=complex)
                sv_in[i] = 1.0
                if _QISKIT and qc is not None:
                    sv_out = Statevector(sv_in).evolve(qc).data
                else:
                    sv_out = _evolve_statevector_numpy(sv_in, U_iso)
                expected = V[:, i]
                err = float(np.linalg.norm(sv_out - expected))
                max_sv_err = max(max_sv_err, err)

            # Roundtrip fidelity on random cross-sector superpositions
            fids = []
            for _ in range(10):
                psi = rng.standard_normal(D) + 1j * rng.standard_normal(D)
                psi /= np.linalg.norm(psi)
                fids.append(float(abs(np.vdot(psi, V.conj().T @ (V @ psi))) ** 2))

            sector_label = "+".join(f"k={k}" for k in sorted(k_sectors))
            print(
                f"  sectors={sector_label}, N={N:2d}: D={D:4d}, m={m}, "
                f"ratio={ratio:.2f}x, err={iso_err:.1e}, "
                f"depth={metrics['circuit_depth']}, 2q={metrics['two_qubit_gates']}"
            )

            records.append({
                "suite_name": "cross_sector_v2",
                "git_commit": "nogit",
                "timestamp_utc": utc_now(),
                "backend": metrics["backend"],
                "family": "multi_sector_isometry",
                "size": N,
                "seed": seed,
                "metrics": {
                    "sectors": sorted(k_sectors),
                    "sector_label": sector_label,
                    "bulk_qubits": N,
                    "boundary_qubits": m,
                    "combined_subspace_dimension": D,
                    "boundary_dimension": 2 ** m,
                    "compression_ratio": ratio,
                    "isometry_error": iso_err,
                    "statevector_max_error": max_sv_err,
                    "roundtrip_fidelity_mean": float(np.mean(fids)),
                    "circuit_depth": metrics["circuit_depth"],
                    "two_qubit_gates": metrics["two_qubit_gates"],
                    "total_gates": metrics["total_gates"],
                },
                "confidence_intervals": {},
                "tags": {"sectors": str(sorted(k_sectors)), "experiment": "cross_sector_isometry"},
            })

    return records


# ══════════════════════════════════════════════════════════════════════════════
# PART B — SECTOR LEAKAGE UNDER PERTURBATION
# ══════════════════════════════════════════════════════════════════════════════

def run_leakage_experiment(
    runner,
    N: int = 4,
    k_center: int = 2,
    Gamma_values: list | None = None,
    t_values: list | None = None,
    seed: int = 7,
) -> list[dict]:
    """
    C4 Part B: sector leakage as a function of perturbation strength Gamma.

    An initial state in the k_center sector is time-evolved under
    H_total = H_XY + H_Gamma(Gamma).  The evolution unitary is compiled
    as a Qiskit UnitaryGate and the state is propagated exactly via
    Qiskit Statevector.  Leakage is the probability of finding the state
    outside the k_center sector after time t.

    The experiment uses N=4 so the unitary dimension is 2^m <= 16,
    keeping circuit compilation tractable.
    """
    if Gamma_values is None:
        Gamma_values = list(np.linspace(0.0, 1.0, 9))
    if t_values is None:
        t_values = [0.5, 1.0, 2.0]

    print(f"\n=== C4 Part B: sector leakage — N={N}, k_center={k_center} ===")
    rng = np.random.default_rng(seed)

    k_min = max(0, k_center - 1)
    k_max = min(N, k_center + 1)
    vecs, sectors_list, idx = build_full_basis(N, k_min, k_max)
    D_total = len(vecs)
    sectors_arr = np.array(sectors_list)
    m = max(1, math.ceil(math.log2(D_total))) if D_total > 1 else 1
    dim_full = 2 ** m

    # Initial state: random superposition in k_center sector
    basis_center = single_sector_basis(N, k_center)
    D_center = len(basis_center)
    psi0_center = rng.standard_normal(D_center) + 1j * rng.standard_normal(D_center)
    psi0_center /= np.linalg.norm(psi0_center)

    # Embed in full basis
    psi0_full = np.zeros(D_total, dtype=np.complex128)
    for i, b in enumerate(basis_center):
        occ_vec = tuple(1 if j in set(b) else 0 for j in range(N))
        psi0_full[idx[occ_vec]] = psi0_center[i]

    # Pad to 2^m for Statevector
    psi0_padded = np.zeros(dim_full, dtype=np.complex128)
    psi0_padded[:D_total] = psi0_full

    # Centre-sector projector in the full padded space
    proj_center = np.zeros(dim_full)
    for i, s in enumerate(sectors_list):
        if s == k_center:
            proj_center[i] = 1.0

    records = []
    first_gamma = True  # record circuit metrics once (they depend on t, not Gamma)

    for Gamma in Gamma_values:
        H_total, _, _, _ = field_perturbation_matrix(N, k_center, Gamma)

        for t in t_values:
            qc, U_evo = build_evolution_circuit(H_total, t, m,
                                                label=f"U_G{Gamma:.2f}_t{t:.1f}")
            if _QISKIT and qc is not None:
                sv_out = Statevector(psi0_padded).evolve(qc).data
            else:
                sv_out = _evolve_statevector_numpy(psi0_padded, U_evo)
            sector_probs = np.abs(sv_out) ** 2
            leakage = max(0.0, float(1.0 - np.dot(proj_center, sector_probs)))

            # Compile once per t to get circuit metrics
            if first_gamma:
                metrics = circuit_metrics(qc, runner, m)
                first_gamma = False
            else:
                backend_name = runner.selection.actual if _QISKIT and runner else "numpy_fallback"
                metrics = {"circuit_depth": None, "two_qubit_gates": None,
                           "total_gates": None, "n_qubits": m,
                           "backend": backend_name,
                           "metrics_method": "unavailable_qiskit_not_installed"}

            print(
                f"  Gamma={Gamma:.3f}, t={t:.1f}: "
                f"leakage={leakage:.6f}"
            )
            records.append({
                "suite_name": "cross_sector_v2",
                "git_commit": "nogit",
                "timestamp_utc": utc_now(),
                "backend": runner.selection.actual if runner else "numpy_fallback",
                "family": "interacting_agents_leakage",
                "size": N,
                "seed": seed,
                "metrics": {
                    "bulk_sites": N,
                    "excitation_center": k_center,
                    "perturbation_strength": round(float(Gamma), 6),
                    "evolution_time": t,
                    "sector_leakage": leakage,
                    "center_sector_probability": 1.0 - leakage,
                    "circuit_depth": metrics["circuit_depth"],
                    "two_qubit_gates": metrics["two_qubit_gates"],
                    "total_gates": metrics["total_gates"],
                    "boundary_qubits": m,
                },
                "confidence_intervals": {},
                "tags": {"experiment": "sector_leakage",
                         "Gamma": str(round(float(Gamma), 3)),
                         "t": str(t)},
            })

    return records


# ══════════════════════════════════════════════════════════════════════════════
# FIGURES
# ══════════════════════════════════════════════════════════════════════════════

def make_cross_sector_figure(ms_records: list[dict]) -> Path:
    """Compression ratio vs N for each sector combination, with circuit depth inset."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))

    combos = [[1, 2], [0, 1, 2], [1, 2, 3]]
    colors  = {str([1,2]): "#2563eb", str([0,1,2]): "#d97706", str([1,2,3]): "#059669"}
    markers = {str([1,2]): "o",       str([0,1,2]): "^",       str([1,2,3]): "s"}
    labels  = {str([1,2]): "k=1,2", str([0,1,2]): "k=0,1,2", str([1,2,3]): "k=1,2,3"}

    Ns = [4, 6]
    for combo in combos:
        key = str(combo)
        sub = [r for r in ms_records if r["metrics"].get("sectors") == combo]
        if not sub:
            continue
        sub_sorted = sorted(sub, key=lambda r: r["metrics"]["bulk_qubits"])
        ratios = [r["metrics"]["compression_ratio"] for r in sub_sorted]
        depths = [r["metrics"]["circuit_depth"] for r in sub_sorted]
        ax1.plot(Ns[:len(ratios)], ratios, marker=markers[key], color=colors[key],
                 label=labels[key], lw=2, ms=7)
        for x, y in zip(Ns[:len(ratios)], ratios):
            ax1.annotate(f"{y:.2f}×", (x, y), xytext=(0, 8),
                         textcoords="offset points", ha="center",
                         fontsize=8, color=colors[key])
        ax2.plot(Ns[:len(depths)], depths, marker=markers[key], color=colors[key],
                 label=labels[key], lw=2, ms=7)

    ax1.set_xlabel("Bulk register size N (sites)", fontsize=11)
    ax1.set_ylabel("Compression ratio N / m", fontsize=11)
    ax1.set_title("(a) Cross-Sector Compression Ratio", fontsize=11)
    ax1.set_xticks(Ns)
    ax1.set_ylim(0.0, 5.0)
    ax1.legend(fontsize=9)
    ax1.grid(True, alpha=0.3)

    ax2.set_xlabel("Bulk register size N (sites)", fontsize=11)
    ax2.set_ylabel("Compiled circuit depth (gates)", fontsize=11)
    ax2.set_title("(b) Compiled Circuit Depth", fontsize=11)
    ax2.set_xticks(Ns)
    ax2.legend(fontsize=9)
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    out = FIGDIR / "fig_cross_sector_compression.png"
    plt.savefig(out, dpi=200, bbox_inches="tight")
    plt.close()
    print(f"\n  -> Figure saved: {out}")
    return out


def make_leakage_figure(leakage_records: list[dict]) -> Path:
    """Sector leakage vs Gamma for each evolution time."""
    fig, ax = plt.subplots(figsize=(7, 4.5))
    t_values = sorted({r["metrics"]["evolution_time"] for r in leakage_records})
    colors = ["#2563eb", "#d97706", "#dc2626"]
    for t, col in zip(t_values, colors):
        sub = sorted(
            [r for r in leakage_records if r["metrics"]["evolution_time"] == t],
            key=lambda r: r["metrics"]["perturbation_strength"],
        )
        Gammas   = [r["metrics"]["perturbation_strength"] for r in sub]
        leakages = [r["metrics"]["sector_leakage"] for r in sub]
        ax.plot(Gammas, leakages, marker="o", color=col, lw=2, ms=5, label=f"t = {t:.1f}")

    ax.set_xlabel("Perturbation strength Γ", fontsize=11)
    ax.set_ylabel("Sector leakage probability", fontsize=11)
    ax.set_title("Sector Leakage Under Transverse-Field Perturbation (N=4, k=2)", fontsize=11)
    ax.set_ylim(-0.02, 1.02)
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    out = FIGDIR / "fig_sector_leakage.png"
    plt.savefig(out, dpi=200, bbox_inches="tight")
    plt.close()
    print(f"  -> Figure saved: {out}")
    return out


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    t0 = time.perf_counter()
    if _QISKIT:
        runner = CircuitRunner(requested_backend="simulator", seed=13)
        print(f"Backend: {runner.selection.actual}  ({runner.selection.note})")
    else:
        runner = None
        print("Running in numpy-fallback mode (circuit metrics not available).")

    ms_records      = run_multi_sector(runner, seed=13)
    leakage_records = run_leakage_experiment(
        runner, N=4, k_center=2,
        Gamma_values=list(np.linspace(0.0, 1.0, 9)),
        t_values=[0.5, 1.0, 2.0],
        seed=7,
    )

    all_records = ms_records + leakage_records
    out_path = RESDIR / "cross_sector_results.jsonl"
    with open(out_path, "w") as f:
        for r in all_records:
            f.write(json.dumps(r) + "\n")
    print(f"\n  -> {out_path}  ({len(all_records)} records)")

    make_cross_sector_figure(ms_records)
    make_leakage_figure(leakage_records)

    print(f"\nAll done in {time.perf_counter() - t0:.1f}s.")
