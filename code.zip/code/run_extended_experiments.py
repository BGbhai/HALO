#!/usr/bin/env python3
"""
Extended experiments for HALO v4:
  Part A: k-excitation holographic compression (k=1,2,3; N=4,8,16,32)
  Part B: Security hardening trend  (n=6..18, 100 trials, vectorised)
  Part C: Both figures
No scipy — Wilson CI and Mann-Kendall implemented inline.
"""
from __future__ import annotations
import itertools, json, math, random, time
from datetime import datetime, timezone
from pathlib import Path
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT   = Path(__file__).resolve().parents[1]   # zenodo_upload/
EXPDIR = Path(__file__).resolve().parent
RESDIR = ROOT / "data"
PAPDIR = ROOT / "latex_source"

# ── stats helpers ─────────────────────────────────────────────────────────────
def wilson_ci(hits, n, z=1.96):
    if n == 0: return (0.0, 1.0)
    p = hits / n
    d = 1 + z**2/n
    c = (p + z**2/(2*n)) / d
    m = z * math.sqrt(p*(1-p)/n + z**2/(4*n**2)) / d
    return (max(0.0, c-m), min(1.0, c+m))

def mann_kendall(vals):
    n = len(vals); S = 0
    for i in range(n-1):
        for j in range(i+1, n):
            d = vals[j]-vals[i]
            if d > 0: S += 1
            elif d < 0: S -= 1
    vS = n*(n-1)*(2*n+5)/18
    z  = ((S-1) if S>0 else (S+1) if S<0 else 0) / math.sqrt(vS)
    def phi(x):
        t = 1/(1+0.2316419*abs(x))
        p = t*(0.31938153+t*(-0.356563782+t*(1.781477937+t*(-1.821255978+t*1.330274429))))
        return 1-(1/math.sqrt(2*math.pi))*math.exp(-0.5*x**2)*p
    pv = 2*(1-phi(abs(z)))
    return S, z, pv, ("decreasing" if S<0 else "increasing" if S>0 else "no trend")

def utc_now():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()

# ══════════════════════════════════════════════════════════════════════════════
# PART A — k-EXCITATION COMPRESSION
# ══════════════════════════════════════════════════════════════════════════════
def k_excitation_isometry(N, k):
    basis = list(itertools.combinations(range(N), k))
    dim   = len(basis)
    m     = max(1, math.ceil(math.log2(dim))) if dim > 1 else 1
    V     = np.zeros((2**m, dim), dtype=np.complex128)
    for i in range(dim): V[i, i] = 1.0
    return V, dim, m

def run_compression_v2(seed=11):
    print("\n=== Part A: k-excitation compression ===")
    rng = np.random.default_rng(seed)
    records = []
    for k in [1, 2, 3]:
        for N in [4, 8, 16, 32]:
            V, dim, m = k_excitation_isometry(N, k)
            gram     = V.conj().T @ V
            iso_err  = float(np.linalg.norm(gram - np.eye(dim), ord='fro'))
            fids = []
            for t in range(10):
                psi = rng.standard_normal(dim) + 1j*rng.standard_normal(dim)
                psi /= np.linalg.norm(psi)
                fids.append(float(abs(np.vdot(psi, V.conj().T @ (V @ psi)))**2))
            ratio = round(N / m, 6)
            print(f"  k={k}, N={N:2d}: dim={dim:5d}, m={m}, ratio={ratio:.3f}x, err={iso_err:.1e}")
            records.append({
                "suite_name": "compression_v2", "git_commit": "nogit",
                "timestamp_utc": utc_now(), "backend": "numpy",
                "family": "k_excitation_isometry", "size": N, "seed": seed,
                "metrics": {
                    "excitation_number": k, "bulk_qubits": N,
                    "boundary_qubits": m, "subspace_dimension": dim,
                    "boundary_dimension": 2**m, "compression_ratio": ratio,
                    "isometry_error": iso_err,
                    "roundtrip_fidelity_mean": float(np.mean(fids)),
                },
                "confidence_intervals": {},
                "tags": {"k": str(k), "model": f"{k}_excitation_subspace"},
            })
    out = RESDIR; out.mkdir(parents=True, exist_ok=True)
    with open(out/"compression_results.jsonl","w") as f:
        for r in records: f.write(json.dumps(r)+"\n")
    print(f"  -> {out}/compression_results.jsonl  ({len(records)} records)")
    return records

# ══════════════════════════════════════════════════════════════════════════════
# PART B — VECTORISED SECURITY EXPERIMENT
# ══════════════════════════════════════════════════════════════════════════════
def _make_instance(n, seed):
    rng = random.Random(seed)
    n_terms = 3*n
    terms = []
    for _ in range(n_terms):
        idx = tuple(sorted(rng.sample(range(n), 3)))
        terms.append((idx, rng.randrange(2), 1.0 + 0.25*rng.random()))
    mask = rng.randrange(1<<n)
    return terms, mask

def _batch_energy(n, terms, mask):
    """Return energy for ALL 2^n bitstrings at once (vectorised)."""
    bs = np.arange(1<<n, dtype=np.int64)   # shape (2^n,)
    masked = bs ^ mask
    energy = np.zeros(1<<n, dtype=np.float64)
    for (i0,i1,i2), tgt, w in terms:
        p = ((masked>>i0)^(masked>>i1)^(masked>>i2)) & 1
        energy += w * (p != tgt)
    return energy

def _greedy_attack(n, terms, mask, restarts, steps, seed):
    rng = random.Random(seed)
    best = float('inf')
    for _ in range(restarts):
        cur = rng.randrange(1<<n)
        cur_e = sum(w * (((cur^mask)>>i0 & 1)^((cur^mask)>>i1 & 1)^
                         ((cur^mask)>>i2 & 1) != tgt) for (i0,i1,i2),tgt,w in terms)
        for _ in range(steps):
            improved = False
            for bit in range(n):
                nb = cur ^ (1<<bit)
                nb_e = sum(w * (((nb^mask)>>i0 & 1)^((nb^mask)>>i1 & 1)^
                               ((nb^mask)>>i2 & 1) != tgt) for (i0,i1,i2),tgt,w in terms)
                if nb_e < cur_e:
                    cur, cur_e, improved = nb, nb_e, True
            if not improved: break
        best = min(best, cur_e)
    return best

def run_security_v2(seed=17, trials=100):
    print("\n=== Part B: security experiment (vectorised) ===")
    sizes   = [6, 8, 10, 12, 14, 16, 18]
    records = []

    for n in sizes:
        t0 = time.perf_counter()
        rand_ok = greedy_ok = combined_ok = 0
        rng_trial = random.Random(seed + 77777 + n)

        for trial in range(trials):
            inst_seed = seed + 10_000*n + trial
            terms, mask = _make_instance(n, inst_seed)

            # Exact ground energy (vectorised, fast)
            energies = _batch_energy(n, terms, mask)
            best     = float(energies.min())

            # Random attacker
            budget  = max(8, 8*n)
            rng_att = random.Random(inst_seed+1)
            rand_best = min(
                sum(w*(((g^mask)>>i0&1)^((g^mask)>>i1&1)^((g^mask)>>i2&1) != t)
                    for (i0,i1,i2),t,w in terms)
                for g in (rng_att.randrange(1<<n) for _ in range(budget))
            )

            # Greedy attacker
            greedy_best = _greedy_attack(n, terms, mask,
                                         restarts=max(2, n//2),
                                         steps=max(6, 2*n),
                                         seed=inst_seed+2)

            if rand_best   <= best + 1e-9: rand_ok   += 1
            if greedy_best <= best + 1e-9: greedy_ok += 1
            if rand_best   <= best + 1e-9 or greedy_best <= best + 1e-9:
                combined_ok += 1

        elapsed = time.perf_counter() - t0
        combined = combined_ok / trials
        ci       = wilson_ci(combined_ok, trials)
        print(f"  n={n:2d}: rate={combined:.4f} CI=[{ci[0]:.3f},{ci[1]:.3f}]  ({elapsed:.1f}s)")

        records.append({
            "suite_name": "security_v2", "git_commit": "nogit",
            "timestamp_utc": utc_now(), "backend": "basic_simulator",
            "family": "masked_local_hamiltonian_proxy",
            "size": n, "seed": seed,
            "metrics": {
                "trials": float(trials),
                "random_attack_success_rate":   rand_ok/trials,
                "greedy_attack_success_rate":   greedy_ok/trials,
                "combined_attack_success_rate": combined,
                "security_margin":              1.0 - combined,
                "qubit_count": n, "gate_count": 0,
                "two_qubit_depth": 0, "ancilla_leakage_rate": 0.0,
                "runtime_sec": elapsed,
            },
            "confidence_intervals": {
                "combined_attack_success_rate": list(ci),
                "logical_fidelity":             [1-ci[1], 1-ci[0]],
            },
            "tags": {"threat_model": "bounded_heuristic_attacker",
                     "trials": str(trials)},
        })

    rates = [r["metrics"]["combined_attack_success_rate"] for r in records]
    S, z_mk, p_mk, trend = mann_kendall(rates)
    print(f"\n  Mann-Kendall: S={S}, z={z_mk:.3f}, p={p_mk:.4f}, trend={trend}")

    out = RESDIR; out.mkdir(parents=True, exist_ok=True)
    with open(out/"security_results.jsonl","w") as f:
        for r in records: f.write(json.dumps(r)+"\n")
    with open(out/"mann_kendall.json","w") as f:
        json.dump({"S":S,"z":z_mk,"p":p_mk,"trend":trend,"rates":rates,"sizes":sizes},f,indent=2)
    print(f"  -> {out}/security_results.jsonl  ({len(records)} records)")
    return records, {"S":S,"z":z_mk,"p":p_mk,"trend":trend}

# ══════════════════════════════════════════════════════════════════════════════
# PART C — FIGURES
# ══════════════════════════════════════════════════════════════════════════════
def make_compression_figure(records):
    fig, ax = plt.subplots(figsize=(7, 4.5))
    colors  = {1:'#7c3aed', 2:'#059669', 3:'#d97706'}
    markers = {1:'o', 2:'s', 3:'^'}
    labels  = {1:'k=1  (single agent)', 2:'k=2  (two agents)', 3:'k=3  (three agents)'}
    Ns = [4,8,16,32]
    for k in [1,2,3]:
        ratios = [r["metrics"]["compression_ratio"]
                  for r in records if r["metrics"]["excitation_number"]==k]
        ax.plot(Ns, ratios, marker=markers[k], color=colors[k],
                label=labels[k], lw=2, ms=7)
        for x,y in zip(Ns,ratios):
            ax.annotate(f'{y:.2f}×',(x,y),xytext=(0,8),
                        textcoords='offset points',ha='center',fontsize=8,color=colors[k])
    ax.set_xlabel('Bulk register size N (sites)', fontsize=11)
    ax.set_ylabel('Compression ratio  (bulk / boundary qubits)', fontsize=11)
    ax.set_title('Holographic Compression across Agent Populations (k=1,2,3)', fontsize=11)
    ax.set_xticks(Ns); ax.set_ylim(0.5,8.0)
    ax.legend(fontsize=9,loc='upper left'); ax.grid(True,alpha=0.3)
    plt.tight_layout()
    out = PAPDIR/"fig_compression_multiexcitation.png"
    plt.savefig(out, dpi=200, bbox_inches='tight'); plt.close()
    print(f"\n=== Fig saved -> {out}")
    return out

def make_security_figure(records, mk):
    fig, ax = plt.subplots(figsize=(7, 4.5))
    sizes = [r["size"] for r in records]
    rates = [r["metrics"]["combined_attack_success_rate"] for r in records]
    lo    = [r["confidence_intervals"]["combined_attack_success_rate"][0] for r in records]
    hi    = [r["confidence_intervals"]["combined_attack_success_rate"][1] for r in records]
    ax.errorbar(sizes, rates, yerr=[[r-l for r,l in zip(rates,lo)],[h-r for h,r in zip(hi,rates)]],
                fmt='o-', color='#7c3aed', lw=2, ms=7, capsize=5, capthick=1.5, elinewidth=1.5,
                label='Combined attack success')
    ax.axhline(0.5, color='gray', ls='--', lw=1, label='Random-guess baseline (0.5)')
    p_str = f"p={mk['p']:.4f}" if mk['p']>=0.0001 else "p<0.0001"
    ax.set_title(f'Security Hardening Trend  (Mann–Kendall S={mk["S"]}, {p_str})', fontsize=11)
    ax.set_xlabel('System size n (qubits)', fontsize=11)
    ax.set_ylabel('Combined attack success rate', fontsize=11)
    ax.set_xticks(sizes); ax.set_ylim(0.0,1.0)
    ax.legend(fontsize=9); ax.grid(True,alpha=0.3)
    plt.tight_layout()
    out = PAPDIR/"fig_security_trend.png"
    plt.savefig(out, dpi=200, bbox_inches='tight'); plt.close()
    print(f"=== Fig saved -> {out}")
    return out

# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    comp = run_compression_v2(seed=11)
    sec, mk = run_security_v2(seed=17, trials=100)
    make_compression_figure(comp)
    make_security_figure(sec, mk)
    print("\nAll done.")
