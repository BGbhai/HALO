#!/usr/bin/env python3
"""
C5: Fully quantum multi-generation HALO evolution — Qiskit circuit implementation.

This script constitutes Claim C5 of the HALO evidence ladder.

A population of P = 8 agents is encoded in a 5-qubit register:
  qubits 0,1  — agent register  (DFS-encoded: |agent(theta)> = cos(theta)|01> + sin(theta)|10>)
  qubits 2,3,4 — population register (3-bit index, superposition over P = 8 agents)

The joint initial state is:
  |Psi_0> = (1/sqrt(P)) sum_i |i>_pop ⊗ |agent(theta_i)>

One generation of evolution consists of three sequential unitary circuits:

  1. Fitness oracle (native gates)
       Phase-flips population slots whose agents satisfy the fitness criterion
       sin²(θᵢ) ≥ FIT_THRESHOLD (evaluated classically from tracked θ values).
       For each fit index i, a multi-controlled phase flip is applied to the
       basis state |i>_pop on qubits 2,3,4 via X-sandwiched CCZ.
       The oracle is rebuilt each generation using updated fit_indices.

  2. Grover diffusion (native gates)
       Inversion-about-mean on the population register, amplifying the
       probability of population indices associated with fit agent states.
       Circuit: H(2,3,4), X(2,3,4), CCZ(2,3,4), X(2,3,4), H(2,3,4).

  3. Coherent mutation (compiled UnitaryGate)
       A block-diagonal unitary applying a distinct DFS rotation delta_i
       to each agent's {|01>, |10>} subspace, conditioned on population index.
       No measurement is performed; the state remains fully coherent.

Evidence threshold (C5)
-----------------------
  Grover oscillation pattern confirmed across G >= 5 generations:
  fit-agent probability peaks above 0.75 on even iterations and
  returns below 0.45 on odd iterations (Grover over-rotation cycle).
  Population entropy tracks inversely with fit probability.
"""

from __future__ import annotations
import json, math, sys, time
from datetime import datetime, timezone
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

try:
    from qiskit import QuantumCircuit, transpile
    from qiskit.circuit.library import UnitaryGate
    from qiskit.quantum_info import Statevector
    sys.path.insert(0, str(Path(__file__).parent))
    from experiments.backends import CircuitRunner
    _QISKIT = True
except ModuleNotFoundError:
    _QISKIT = False
    print("WARNING: qiskit not found — running in numpy-fallback mode.")
    print("         Install requirements.txt for full circuit metrics.")

# ── paths ──────────────────────────────────────────────────────────────────
ROOT   = Path(__file__).resolve().parents[1]
RESDIR = ROOT / "data"
FIGDIR = ROOT / "latex_source"
RESDIR.mkdir(parents=True, exist_ok=True)

def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


# ── register layout ──────────────────────────────────────────────────────────
# qubits 0,1 = agent register;  qubits 2,3,4 = population register
# In Qiskit (little-endian): state index = agent_idx + pop_idx * 4
#   agent_idx in {0,1,2,3}: |00>=0, |01>=1, |10>=2, |11>=3
#   pop_idx in {0,...,P-1}: population slot index
_N_AGENT   = 2     # agent register qubits
_N_POP     = 3     # population register qubits (for P=8)
_N_TOTAL   = _N_AGENT + _N_POP  # = 5
_P_DEFAULT = 8     # 2^_N_POP
FIT_THRESHOLD = 0.70   # sin²(θ) ≥ this → agent is "fit"


# ══════════════════════════════════════════════════════════════════════════════
# STATE PREPARATION
# ══════════════════════════════════════════════════════════════════════════════

def initial_statevector(agent_thetas: list[float]) -> np.ndarray:
    """
    Build |Psi_0> = (1/sqrt(P)) sum_i |i>_pop ⊗ |agent(theta_i)>

    State vector length: 4P (agent basis size 4, population size P).
    Index encoding (Qiskit little-endian, agent in qubits 0,1):
        sv[pop_idx * 4 + agent_idx]  =  amplitude of |pop_idx, agent_idx>

    The DFS encoding places amplitude only in agent states 1 (|01>) and 2 (|10>).
    """
    P = len(agent_thetas)
    sv = np.zeros(4 * P, dtype=np.complex128)
    norm = math.sqrt(P)
    for i, theta in enumerate(agent_thetas):
        sv[i * 4 + 1] = math.cos(theta) / norm   # |01> component
        sv[i * 4 + 2] = math.sin(theta) / norm   # |10> component (fit state)
    return sv


# ══════════════════════════════════════════════════════════════════════════════
# CIRCUIT BUILDING
# ══════════════════════════════════════════════════════════════════════════════

def _apply_oracle_numpy(sv: np.ndarray, fit_indices: list[int], P: int) -> np.ndarray:
    """
    Numpy fallback: phase-flip the entire population block for each fit index.

    For each i in fit_indices, negates amplitudes sv[i*4 : i*4+4], which
    corresponds to applying a -1 phase to the population basis state |i>_pop
    regardless of the agent register state.
    """
    out = sv.copy()
    for i in fit_indices:
        out[i * 4 : i * 4 + 4] *= -1.0
    return out


def _apply_diffusion_numpy(sv: np.ndarray, P: int) -> np.ndarray:
    """Numpy fallback: Grover inversion-about-mean on population register."""
    out = sv.copy()
    for j in range(4):
        amps = np.array([sv[i * 4 + j] for i in range(P)])
        mean = amps.sum() / P
        for i in range(P):
            out[i * 4 + j] = 2.0 * mean - amps[i]
    return out


def _apply_mutation_numpy(sv: np.ndarray, deltas: list[float]) -> np.ndarray:
    """Numpy fallback: block-diagonal DFS rotation."""
    out = sv.copy()
    for i, delta in enumerate(deltas):
        c, s = math.cos(delta), math.sin(delta)
        lo = i * 4 + 1
        hi = i * 4 + 2
        lo_val, hi_val = sv[lo], sv[hi]
        out[lo] = c * lo_val - s * hi_val
        out[hi] = s * lo_val + c * hi_val
    return out


def build_oracle_circuit(fit_indices: list[int]):
    """
    Fitness oracle: phase-flip each population basis state |i>_pop for i in fit_indices.

    For each fit index i, implements a multi-controlled phase flip on qubits 2,3,4:
      - X-flip population qubits where the corresponding bit of i is 0
      - Apply H(4), CCX(2,3,4), H(4)  (= CCZ on population register)
      - X-flip population qubits back

    This selectively applies a -1 phase to |i>_pop while leaving all other
    population basis states unchanged.  The agent register (qubits 0,1) is
    not touched.

    Returns None when Qiskit is unavailable.
    """
    if not _QISKIT:
        return None
    qc = QuantumCircuit(_N_TOTAL, name="fitness_oracle")
    pop_qubits = [_N_AGENT + b for b in range(_N_POP)]   # [2, 3, 4]
    for i in fit_indices:
        # Decompose i into bits (LSB first, matching Qiskit's little-endian order)
        bits = [(i >> b) & 1 for b in range(_N_POP)]
        # X-flip qubits where bit is 0 (so |i>_pop maps to |111>)
        for bit, q in zip(bits, pop_qubits):
            if bit == 0:
                qc.x(q)
        # Phase flip |111> via H(target), CCX, H(target)
        qc.h(pop_qubits[-1])
        qc.ccx(*pop_qubits)
        qc.h(pop_qubits[-1])
        # X-flip back
        for bit, q in zip(bits, pop_qubits):
            if bit == 0:
                qc.x(q)
    return qc


def build_diffusion_circuit() -> QuantumCircuit:
    """
    Grover inversion-about-mean on the population register (qubits 2,3,4).

    Implements (2 |s><s| - I) on qubits 2,3,4 where |s> = (1/sqrt(P)) sum_i |i>.
    Acts as the identity on the agent register (qubits 0,1).

    Circuit (standard Grover diffusion on 3 qubits):
      H(2,3,4)                    — rotate to computational basis
      X(2,3,4)                    — map |000> to |111>
      H(4), CCX(2,3,4), H(4)     — phase flip |111> (= CCZ equivalent)
      X(2,3,4)                    — restore
      H(2,3,4)                    — rotate back

    Returns None when Qiskit is unavailable.
    """
    if not _QISKIT:
        return None
    qc = QuantumCircuit(_N_TOTAL, name="grover_diffusion")
    # H on population register
    for q in [2, 3, 4]:
        qc.h(q)
    # X on population register
    for q in [2, 3, 4]:
        qc.x(q)
    # Phase flip |111> via CCZ = H, CCX, H on target qubit
    qc.h(4)
    qc.ccx(2, 3, 4)
    qc.h(4)
    # X on population register (undo)
    for q in [2, 3, 4]:
        qc.x(q)
    # H on population register
    for q in [2, 3, 4]:
        qc.h(q)
    return qc


def build_mutation_circuit(deltas: list[float]) -> QuantumCircuit:
    """
    Coherent mutation: block-diagonal DFS rotation, different per population slot.

    For population index i, applies the unitary
        U_mut(delta_i) to the agent register's {|01>, |10>} subspace:
            U_mut[|01>] = cos(delta_i)|01> - sin(delta_i)|10>
            U_mut[|10>] = sin(delta_i)|01> + cos(delta_i)|10>

    The full (4P x 4P) unitary is constructed as a block-diagonal matrix
    and compiled into a Qiskit UnitaryGate.  In the Qiskit little-endian
    convention (state index = agent_idx + pop_idx * 4), the block for
    population slot i occupies rows/cols {i*4, i*4+1, i*4+2, i*4+3}.

    Returns None when Qiskit is unavailable.
    """
    if not _QISKIT:
        return None
    P = len(deltas)
    dim = 4 * P
    U = np.eye(dim, dtype=complex)
    for i, delta in enumerate(deltas):
        c, s = math.cos(delta), math.sin(delta)
        lo = i * 4 + 1   # |01> index
        hi = i * 4 + 2   # |10> index
        U[lo, lo] =  c;  U[lo, hi] = -s
        U[hi, lo] =  s;  U[hi, hi] =  c
    gate = UnitaryGate(U, label="mutation")
    qc = QuantumCircuit(_N_TOTAL, name="coherent_mutation")
    qc.append(gate, range(_N_TOTAL))
    return qc


def circuit_metrics(qc, runner, opt_level: int = 1) -> dict:
    """Transpile circuit and return depth and two-qubit gate count.

    Falls back to hardcoded unavailable metrics when Qiskit is not installed
    or circuit is None.
    """
    if _QISKIT and qc is not None:
        compiled = transpile(qc, runner._backend,
                             seed_transpiler=runner.seed,
                             optimization_level=opt_level)
        return {
            "circuit_depth": compiled.depth(),
            "two_qubit_gates": compiled.num_nonlocal_gates(),
            "total_gates": compiled.size(),
        }
    else:
        return {
            "circuit_depth": None,
            "two_qubit_gates": None,
            "total_gates": None,
            "metrics_method": "unavailable_qiskit_not_installed"
        }


# ══════════════════════════════════════════════════════════════════════════════
# OBSERVABLES  (from statevector, no collapse)
# ══════════════════════════════════════════════════════════════════════════════

def marginal_population_probs(sv: np.ndarray, P: int) -> np.ndarray:
    """Marginal probability of each population slot: p_i = sum_j |sv[i*4+j]|^2."""
    return np.array([
        float(np.sum(np.abs(sv[i * 4: i * 4 + 4]) ** 2))
        for i in range(P)
    ])


def fit_probability(sv: np.ndarray, fit_indices: list[int], P: int) -> float:
    """
    Total probability of the population register pointing to a fit agent slot.

    P_fit = sum_{i in fit_indices} p_i
    where p_i = sum_j |sv[i*4+j]|^2  is the marginal probability of slot i.

    This is the correct observable for Grover-amplified selection: it measures
    how much amplitude has been concentrated into fit population indices,
    rather than measuring the agent register state directly.
    """
    probs = marginal_population_probs(sv, P)
    return float(sum(probs[i] for i in fit_indices))


def population_entropy(sv: np.ndarray, P: int) -> float:
    """Shannon entropy of the marginal population distribution (nats)."""
    probs = marginal_population_probs(sv, P)
    probs = probs[probs > 1e-15]
    return float(-np.sum(probs * np.log(probs)))


# ══════════════════════════════════════════════════════════════════════════════
# MAIN EXPERIMENT
# ══════════════════════════════════════════════════════════════════════════════

def run_quantum_evolution(
    runner,
    P: int = 8,
    G: int = 5,
    sigma: float = 0.05,
    seed: int = 42,
) -> list[dict]:
    """
    Run G generations of fully quantum HALO evolution.

    Each generation:
      1. Compute fit_indices classically from current agent_thetas
         (those i where sin²(θᵢ) ≥ FIT_THRESHOLD).
      2. Build fitness oracle circuit for current fit_indices.
      3. Apply oracle circuit (phase-kickback on fit population slots).
      4. Apply Grover diffusion circuit (amplitude amplification).
      5. Apply coherent mutation circuit (different rotation per agent).
      6. Record observables via Statevector — no state collapse.
      7. Update classical angle tracking.

    A single projective measurement on the population register is taken
    only after all G generations are complete.

    Parameters
    ----------
    runner : CircuitRunner (or None in numpy-fallback mode)
    P      : population size (must be 8 for the default 5-qubit layout)
    G      : number of generations
    sigma  : mutation standard deviation (radians)
    seed   : RNG seed for reproducibility
    """
    assert P == 2 ** _N_POP, f"P must equal 2^{_N_POP} = {2**_N_POP} for this layout."
    rng = np.random.default_rng(seed)

    # ── Initial agent angles ───────────────────────────────────────────────
    # 2 of P=8 agents start near theta=pi/2 (fit); rest start near 0 (unfit).
    n_fit_init = P // 4
    angles_unfit = list(np.linspace(0.05, 0.55, P - n_fit_init))
    angles_fit   = list(np.linspace(1.10, 1.45, n_fit_init))
    agent_thetas = angles_unfit + angles_fit

    # ── Build static diffusion circuit (never changes) ───────────────────
    qc_diffusion = build_diffusion_circuit()
    diffusion_metrics = circuit_metrics(qc_diffusion, runner)

    # ── Compute initial fit_indices and oracle metrics ────────────────────
    fit_indices_0 = [i for i, t in enumerate(agent_thetas)
                     if math.sin(t) ** 2 >= FIT_THRESHOLD]
    qc_oracle_0   = build_oracle_circuit(fit_indices_0)
    oracle_metrics = circuit_metrics(qc_oracle_0, runner)

    print(f"\n=== C5 Quantum evolution: P={P}, G={G}, sigma={sigma} ===")
    print(f"  Initial fit indices: {fit_indices_0}  "
          f"(sin² thresholds: {[round(math.sin(agent_thetas[i])**2,3) for i in fit_indices_0]})")
    print(f"  Oracle:    depth={oracle_metrics['circuit_depth']}, "
          f"2q={oracle_metrics['two_qubit_gates']}")
    print(f"  Diffusion: depth={diffusion_metrics['circuit_depth']}, "
          f"2q={diffusion_metrics['two_qubit_gates']}")
    print(f"\n  {'Gen':>4}  {'P_fit':>8}  {'Entropy':>10}  {'fit_idx'}")
    print("  " + "-" * 50)

    sv = initial_statevector(agent_thetas)

    records = []
    mutation_metrics_cache = None

    for g in range(G + 1):
        # Compute fit_indices from current classical thetas
        fit_indices = [i for i, t in enumerate(agent_thetas)
                       if math.sin(t) ** 2 >= FIT_THRESHOLD]

        p_fit   = fit_probability(sv, fit_indices, P)
        entropy = population_entropy(sv, P)

        print(f"  {g:>4}  {p_fit:>8.4f}  {entropy:>10.4f}  {fit_indices}")

        # Build mutation circuit for this generation to get metrics on gen 0
        deltas = rng.normal(0.0, sigma, size=P).tolist()
        qc_mut = build_mutation_circuit(deltas)
        if mutation_metrics_cache is None:
            mutation_metrics_cache = circuit_metrics(qc_mut, runner)
            print(f"  Mutation:  depth={mutation_metrics_cache['circuit_depth']}, "
                  f"2q={mutation_metrics_cache['two_qubit_gates']}")

        records.append({
            "suite_name": "quantum_evolution_v2",
            "git_commit": "nogit",
            "timestamp_utc": utc_now(),
            "backend": runner.selection.actual if runner else "numpy_fallback",
            "family": "quantum_grover_evolution",
            "size": P,
            "seed": seed,
            "metrics": {
                "generation": g,
                "population_size": P,
                "n_generations": G,
                "mutation_sigma": sigma,
                "fit_probability": p_fit,
                "population_entropy": entropy,
                "max_entropy": float(math.log(P)),
                "fit_indices": fit_indices,
                "n_fit": len(fit_indices),
                "agent_thetas": [round(t, 6) for t in agent_thetas],
                "oracle_depth": oracle_metrics["circuit_depth"],
                "oracle_two_qubit_gates": oracle_metrics["two_qubit_gates"],
                "diffusion_depth": diffusion_metrics["circuit_depth"],
                "diffusion_two_qubit_gates": diffusion_metrics["two_qubit_gates"],
                "mutation_depth": mutation_metrics_cache["circuit_depth"],
                "mutation_two_qubit_gates": mutation_metrics_cache["two_qubit_gates"],
            },
            "confidence_intervals": {},
            "tags": {"experiment": "quantum_grover_evolution", "generation": str(g)},
        })

        if g == G:
            break

        # ── One fully quantum generation ─────────────────────────────────
        # Step 1: fitness oracle (phase-kickback on fit population slots)
        qc_oracle = build_oracle_circuit(fit_indices)
        if _QISKIT and qc_oracle is not None:
            sv = Statevector(sv).evolve(qc_oracle).data
        else:
            sv = _apply_oracle_numpy(sv, fit_indices, P)

        # Step 2: Grover diffusion
        if _QISKIT and qc_diffusion is not None:
            sv = Statevector(sv).evolve(qc_diffusion).data
        else:
            sv = _apply_diffusion_numpy(sv, P)

        # Step 3: coherent mutation (deltas already drawn above for metrics)
        qc_mut_current = build_mutation_circuit(deltas)
        if _QISKIT and qc_mut_current is not None:
            sv = Statevector(sv).evolve(qc_mut_current).data
        else:
            sv = _apply_mutation_numpy(sv, deltas)

        # Update classical angle tracking (for oracle and fitness evaluation)
        agent_thetas = [t + d for t, d in zip(agent_thetas, deltas)]

    # ── Final projective readout ─────────────────────────────────────────
    probs = marginal_population_probs(sv, P)
    final_agent = int(rng.choice(P, p=probs / probs.sum()))
    final_fit   = float(math.sin(agent_thetas[final_agent]) ** 2)
    print(f"\n  Final readout: agent {final_agent}, fitness = {final_fit:.4f}")

    return records


# ══════════════════════════════════════════════════════════════════════════════
# FIGURE
# ══════════════════════════════════════════════════════════════════════════════

def make_evolution_figure(records: list[dict]) -> Path:
    """Two-panel: fit-agent probability and population entropy over generations."""
    gens    = [r["metrics"]["generation"] for r in records]
    p_fit   = [r["metrics"]["fit_probability"] for r in records]
    entropy = [r["metrics"]["population_entropy"] for r in records]
    max_H   = records[0]["metrics"]["max_entropy"]
    P       = records[0]["metrics"]["population_size"]
    n_fit   = records[0]["metrics"]["n_fit"]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))

    ax1.plot(gens, p_fit, marker="o", color="#7c3aed", lw=2, ms=7)
    ax1.axhline(n_fit / P, color="gray", ls="--", lw=1,
                label=f"initial fit fraction ({n_fit}/{P})")
    for g, p in zip(gens, p_fit):
        ax1.annotate(f"{p:.3f}", (g, p), xytext=(0, 7),
                     textcoords="offset points", ha="center", fontsize=8)
    ax1.set_xlabel("Generation", fontsize=11)
    ax1.set_ylabel("Fit-agent probability", fontsize=11)
    ax1.set_title("(a) Quantum Selection via Amplitude Amplification", fontsize=11)
    ax1.set_ylim(0.0, 1.05)
    ax1.set_xticks(gens)
    ax1.legend(fontsize=9)
    ax1.grid(True, alpha=0.3)

    ax2.plot(gens, entropy, marker="s", color="#059669", lw=2, ms=7)
    ax2.axhline(max_H, color="gray", ls="--", lw=1, label=f"max entropy = ln({P})")
    ax2.set_xlabel("Generation", fontsize=11)
    ax2.set_ylabel("Population entropy (nats)", fontsize=11)
    ax2.set_title("(b) Population Diversity over Generations", fontsize=11)
    ax2.set_ylim(0.0, max_H * 1.1)
    ax2.set_xticks(gens)
    ax2.legend(fontsize=9)
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    out = FIGDIR / "fig_quantum_evolution.png"
    plt.savefig(out, dpi=200, bbox_inches="tight")
    plt.close()
    print(f"\n  -> Figure saved: {out}")
    return out


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    t0 = time.perf_counter()
    if _QISKIT:
        runner = CircuitRunner(requested_backend="simulator", seed=42)
        print(f"Backend: {runner.selection.actual}  ({runner.selection.note})")
    else:
        runner = None
        print("Running in numpy-fallback mode (circuit metrics not available).")

    records = run_quantum_evolution(runner, P=8, G=5, sigma=0.05, seed=42)

    out_path = RESDIR / "evolution_results.jsonl"
    with open(out_path, "w") as f:
        for r in records:
            f.write(json.dumps(r) + "\n")
    print(f"\n  -> {out_path}  ({len(records)} records)")

    make_evolution_figure(records)
    print(f"\nAll done in {time.perf_counter() - t0:.1f}s.")
